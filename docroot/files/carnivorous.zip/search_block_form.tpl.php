<?php 
    //echo "<pre>"; print_r($form); echo "</pre>"; 
    //echo "foo";
    //echo "<pre>"; print $search; echo "</pre>"; 
    //echo "boo";
    //echo "<pre>"; print_r($search_form); echo "</pre>"; 
    //echo "hoo";
    //exit; 
?>  
    <div class="container-inline">
      <?php print $search_form; ?>
    </div>
    <?php //print $form['search_block_form']; ?>
    <?php //print $form['submit']; ?>
    <ul>
      <li>
      <?php //print l('Advanced Search', 'search/node', NULL, 'search-form'); ?>
      </li>
    </ul>
    <?php //print $form['hidden']; ?>
    