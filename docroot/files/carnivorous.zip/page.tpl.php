<?php // $Id: page.tpl.php,v 1.3 2009/06/03 15:22:52 rolfmeijer Exp $ ?>
<?php drupal_rebuild_theme_registry(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?php print $language->language; ?>" xml:lang="
  <?php print $language->language; ?>"> 
  <head>    
    <title>
      <?php print $head_title; ?>
    </title>    
    <?php print $head; ?>    
    <?php print $styles; ?>    
    <?php print $scripts; ?>
  </head>
  <body>
    <div id="wrapper">
      <!--zaciatok celok -->
      <div class="header">
        <div class="login">
            <?php print carnivorous_user_bar(); ?>
        </div>
        <!--koniec topLogin -->
      </div>	
      <!--koniec toptop -->	
      <div class="clear">&nbsp;
      </div>	
      <div id="logo">
        <a href="<?php echo base_path(); ?>" title="Spoločenstvo Slovenských Mäsožravkárov">
          <span>Spoločenstvo Slovenských Mäsožravkárov
          </span></a></div>	
      <div class="slideshow">		
        <img src="<?php echo base_path() . path_to_theme(). "/images/1.png"; ?>" width="998" height="138" alt="" />	
      </div>	 
      <div class="topmenu">
        <div id="mainMenu">	
        <?php if (isset($primary_links)) { ?>
            <?php print theme('links', $primary_links) ?>
        <?php } ?>
        </div>
        <div id="submenu">	
          <?php if (isset($primary_links_level2)) { ?>
            <?php print theme('links', $primary_links_level2) ?>
        <?php } ?>
        </div>
      </div>
      <div id="obsah">
        <div id="left">
          <div id="header">
            <div class="wrap">   
              <div id="slide-holder">
                <div id="slide-runner">    
                    <img id="slide-img-1" src="<?php echo base_path() . path_to_theme(). "/images/nature-photo.png"; ?>" class="slide" alt="" />
                  <div id="slide-controls">     
                    <p id="slide-client" class="text"><strong></strong>
                      <span>
                      </span>
                    </p>     
                    <p id="slide-desc" class="text">
                    </p>     
                    <p id="slide-nav">
                    </p>    
                  </div>
                </div>	 	
                <!--content featured gallery here -->    
              </div>   
<script type="text/javascript">
    //if(!window.slider) var slider={};
    //slider.data=[
    //{"id":"slide-img-1","client":"nature beauty","desc":"nature beauty photography"},
    //{"id":"slide-img-2","client":"nature beauty","desc":"add your description here"},
    //{"id":"slide-img-3","client":"nature beauty","desc":"add your description here"},
    //{"id":"slide-img-4","client":"nature beauty","desc":"add your description here"},
    //{"id":"slide-img-5","client":"nature beauty","desc":"add your description here"},
    //{"id":"slide-img-6","client":"nature beauty","desc":"add your description here"},
    //{"id":"slide-img-7","client":"nature beauty","desc":"add your description here"}];
   </script>  
            </div>
          </div>
          <!--/header-->
          <div id="content">
            <?php  if ($messages) { print $messages; }?>
            
            <?php  if ($help) { print $help; }?>

            <?php  if ($content_top) { print $content_top; }?>

            <?php if ($tabs) { ?>
              <div class="tabs"><?php print $tabs ?></div>
            <?php } ?>
            
            <?php if ($title) {  ?>
              <h1 class="title"><?php print $title ?></h1>
            <?php } ?>
            
            <?php print $content; ?> 
          </div>
          <!--koniec content -->
        </div>
        <!--koniec left -->
        <div id="right">
          <div class="rightSearch">
            <?php print carnivorous_search_block(); ?>
          </div>
          <!--koniec rightSearch -->
          <div class="userMap">
            <?php  if ($user_map) { print $user_map; }?>
            <a href=""><img src="<?php echo base_path() . path_to_theme(). "/images/mapa.png"; ?>" alt="" /></a>
          </div>

          <?php  if ($right_block) { print $right_block; }?>
        </div>
        <!--koniec right -->
      </div>
      <!--koniec obsah -->
      <div class="clear">&nbsp;
      </div>
    </div>
    <!--koniec celok -->
    <div id="footerr">
      <div id="footer">
        <p>
          <a href="#">
            <img src="<?php echo base_path() . path_to_theme(). "/images/logowebsupport.png"; ?>" alt="" /></a> 
        </p>
        <p>Spoločenstvo slovenských masožravkárov<br />© 2010 - 2011, Všetky práva vyhradené<br />Hosting sponzoruje spoločnosť 
          <a href="http://websupport.sk/">websupport</a>.<br />Vyrobilo 
          <a href="http://www.webnamieru.sk/">Webnamieru.sk</a> 
        </p>
        <p class="footermenu">
          <a href="#">SSM</a>   |   
          <a href="#">Najčastejšie otázky</a>   |   
          <a href="#">Encyklopédia MR</a>   |   
          <a href="#">On-line pomoc</a>
        </p>
        <?php if ($footer_message): ?>
            <?php //print $footer_message; ?>
        <?php endif; ?>
        <?php if ($footer): ?>
            <?php //print $footer; ?>
        <?php endif; ?>        
      </div>
    </div>
    <?php print $closure; ?>
</body>
</html>