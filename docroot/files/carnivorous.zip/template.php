<?php // $Id: template.php,v 1.2 2009/05/31 14:10:39 rolfmeijer Exp $ 

function carnivorous_search_block() {                                                            
  $form = drupal_get_form('search_block_form');
  $output = theme('search_block_form', $form); 
  return $output;                                                                     
}

function carnivorous_theme(&$existing, $type, $theme, $path) {  
  $hooks['search_block_form'] = array(
    'template' => 'templates/search_block_form',
    'arguments' => array('form' => NULL)
    // other theme registration code...
  );

  return $hooks;
}

function carnivorous_preprocess_search_block_form(&$vars) {
    // Modify elements of the search form
    unset($vars['form']['search_block_form']['#title']);

    // Set a default value for the search box
    $vars['form']['search_block_form']['#value'] = t('Search');
   
    // Add a custom class to the search box
    // Set yourtheme.css > #search-block-form .form-text { color: #888888; }
    $vars['form']['search_block_form']['#attributes'] = array(
       'onblur' => "if (this.value == '') {this.value = '".$vars['form']['search_block_form']['#value']."';} this.style.fontStyle = \"italic\"; this.style.color = \"#736F6E\";",
       'onfocus' => "if (this.value == '".$vars['form']['search_block_form']['#value']."') {this.value = '';} this.style.fontStyle = \"normal\"; this.style.color = \"#1E1E1E\";" );

    // Modify elements of the submit button
    unset($vars['form']['submit']);

    // Change submit button into image button - NOTE: '#src' leading '/' automatically added
    $vars['form']['submit']['image_button'] = array('#type' => 'image_button', '#src' => base_path() . path_to_theme() . '/images/bsearch.png');

    // Rebuild the rendered version (search form only, rest remains unchanged)
    unset($vars['form']['search_block_form']['#printed']);
    $vars['search']['search_block_form'] = drupal_render($vars['form']['search_block_form']);

    // Rebuild the rendered version (submit button, rest remains unchanged)
    unset($vars['form']['submit']['#printed']);
    $vars['search']['submit'] = drupal_render($vars['form']['submit']);
   
    // Collect all form elements to print entire form
    $vars['search_form'] = implode($vars['search']);
}

?>

