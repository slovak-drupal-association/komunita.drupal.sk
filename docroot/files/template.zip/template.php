<?php
function alphorn_theme() {
  return array(
    // The form ID.
    'user_login_block' => array(
      // Forms always take the form argument.
      'arguments' => array('form' => NULL),
    ),
  );
}
function alphorn_user_login_block() {
  if ( $user->uid ) { return (drupal_render(user_user('view')));  }else{
  $form = array(
    '#action' => url($_GET['q'], array('query' => drupal_get_destination())), 
    '#id' => 'user-login-form', 
    '#validate' => user_login_default_validators(), 
    '#submit' => array('user_login_submit'),
  );
  $form['name'] = array(
    '#type' => 'textfield',
    '#id' => 'edit-name',
    '#title' => t('Username'), 
    '#maxlength' => USERNAME_MAX_LENGTH, 
    '#size' => 15, 
    '#required' => TRUE,
    '#weight' => 1,
  );
  $form['pass'] = array(
    '#type' => 'password', 
    '#id' => 'edit-pass',
    '#title' => t('Password'), 
    '#maxlength' => 60, 
    '#size' => 15, 
    '#required' => TRUE,
    '#weight' => 2,
  );
  $form['submit'] = array(
    '#type' => 'submit', 
    '#value' => t('Log in'),
    '#weight' => 3,
  ); 
  $items = array();
  if (variable_get('user_register', 1)) {
    $items[] = l(t('Create new account'), $current_path, array('attributes' => array('title' => t('Create a new user account.')),'fragment' => "register"));
  }
  $items[] = l(t('Request new password'), $current_path, array('attributes' => array('title' => t('Request new password via e-mail.')),'fragment' => "request_password"));
  $form['links'] = array('#value' => theme('item_list', $items), '#weight' => 100);
  return (drupal_render($form));}
}
?>
